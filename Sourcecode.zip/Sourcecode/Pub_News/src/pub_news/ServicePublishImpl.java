package pub_news;

public class ServicePublishImpl implements ServicePublish {
	public String publishService() {
		return "Execute the Movie publisher";
	}

	@Override
	public String publicService() {
		// TODO Auto-generated method stub
		return null;
	}

}

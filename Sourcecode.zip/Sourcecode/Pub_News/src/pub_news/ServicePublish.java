package pub_news;

public interface ServicePublish {
 public String publicService();
}


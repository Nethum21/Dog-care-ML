package pub_movies;

public interface ServicePublish {
	public String publishService();

}

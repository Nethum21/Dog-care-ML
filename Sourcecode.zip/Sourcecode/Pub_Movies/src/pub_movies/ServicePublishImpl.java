package pub_movies;

public class ServicePublishImpl implements ServicePublish  {
	
	public String publishService() {
		return "Execute the Movie publisher";
	}

}

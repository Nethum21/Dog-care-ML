package pub_kids;

public interface ServicePublish {
	public String publishService();

}

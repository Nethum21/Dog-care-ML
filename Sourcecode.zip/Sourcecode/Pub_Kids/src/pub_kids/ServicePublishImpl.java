package pub_kids;

public class ServicePublishImpl implements ServicePublish {
	public String publishService() {
		return "Execute the Kids publish Channel";
	}

}

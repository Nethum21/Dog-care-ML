package pub_sports;

public class ServicePublishImpl implements ServicePublish {
	public String publishService() {
		return "Execute the Sports publisher";
	}

}

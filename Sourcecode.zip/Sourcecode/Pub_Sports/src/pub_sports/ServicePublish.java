package pub_sports;

public interface ServicePublish {
	public String publishService();

}
